const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
 email: {
 type: String,
 required: true,
 unique: true,
 lowercase: true,
 },
 password: {
 type: String,
 required: true,
 minlength: 6,
 }
});
const User = mongoose.m


const bcrypt = require('bcrypt');
// fire a function before doc saved to db
userSchema.pre('save', async function(next) {
 const salt = await bcrypt.genSalt();
 this.password = await bcrypt.hash(this.password, salt);
 next();
});
